# Alif Learning Hub Register

i wanna build awebsite for online learning system but the website is just for rejistration only so build arejistration sytem  with kategory like qaida nezertejwid hifz kitab

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://alif-learning-hub-register.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/340c9141-2cdb-48a6-928a-1b9c9614b862).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
