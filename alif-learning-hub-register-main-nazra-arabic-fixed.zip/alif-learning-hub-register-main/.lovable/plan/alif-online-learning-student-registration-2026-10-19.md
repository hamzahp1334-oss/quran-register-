# Alif Online Learning — Student Registration

## What gets built
1. **Home page (/)** — welcome section for "Alif Online Learning", the four courses shown as cards (Qaida, Nazra / Tajweed, Hifz, Kitab), and a "Register now" button.
2. **Registration page (/register)** — form with:
   - Course (Qaida, Nazra/Tajweed, Hifz, Kitab)
   - Full name, gender, age
   - Parent/guardian name (optional, for children)
   - Phone / WhatsApp, email (optional), country / city
   - Current level (beginner / some knowledge / advanced)
   - Preferred class time (morning / afternoon / evening)
   - Notes
   - Success screen after submitting.
3. **Admin page (/admin)** — only hamzahp1334@gmail.com can sign in. Shows all registrations in a table, filter by course, search by name/phone, mark status (new / contacted / enrolled), delete.

## Look
Emerald & Gold: deep emerald (#064e3b, #0d7a5f), gold accents (#c9a84c), cream background (#f5f0e0). Elegant serif headings (e.g. Amiri / Cormorant) with clean body font, subtle Islamic geometric pattern accents.

## Technical details
- Enable Lovable Cloud; table `registrations` (anyone can insert, only admin can read/update/delete).
- `user_roles` table + `has_role` function; admin role granted to hamzahp1334@gmail.com via trigger on signup with that email.
- Email/password sign-in for admin at /auth; admin page under `_authenticated`.
- Zod validation on the form; per-route head metadata.
