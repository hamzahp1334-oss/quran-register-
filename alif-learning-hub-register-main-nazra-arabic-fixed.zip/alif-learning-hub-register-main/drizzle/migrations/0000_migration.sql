create type public.app_role as enum ('admin','user');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id=_user_id and role=_role) $$;

create or replace function public.grant_admin_on_signup()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  if lower(new.email) = 'hamzahp1334@gmail.com' then
    insert into public.user_roles(user_id, role) values (new.id, 'admin') on conflict do nothing;
  end if;
  return new;
end $$;
create trigger on_auth_user_created_admin after insert on auth.users
for each row execute function public.grant_admin_on_signup();

create table public.registrations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  course text not null check (course in ('qaida','nazra_tajweed','hifz','kitab')),
  full_name text not null check (char_length(full_name) between 1 and 100),
  gender text not null check (gender in ('male','female')),
  age int not null check (age between 3 and 100),
  guardian_name text check (char_length(guardian_name) <= 100),
  phone text not null check (char_length(phone) between 5 and 30),
  email text check (char_length(email) <= 255),
  location text not null check (char_length(location) between 1 and 120),
  level text not null check (level in ('beginner','some','advanced')),
  preferred_time text not null check (preferred_time in ('morning','afternoon','evening')),
  notes text check (char_length(notes) <= 1000),
  status text not null default 'new' check (status in ('new','contacted','enrolled'))
);
grant insert on public.registrations to anon, authenticated;
grant select, update, delete on public.registrations to authenticated;
grant all on public.registrations to service_role;
alter table public.registrations enable row level security;
create policy "anyone can register" on public.registrations for insert to anon, authenticated with check (status = 'new');
create policy "admin read" on public.registrations for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin update" on public.registrations for update to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin delete" on public.registrations for delete to authenticated using (public.has_role(auth.uid(),'admin'));