import { z } from "zod";

export const COURSES = [
  { id: "qaida", name: "Qaida", arabic: "القاعدة", desc: "Learn the Arabic letters and the foundations of reading the Quran." },
  { id: "nazra", name: "Nazra", arabic: "نَظْرَة", desc: "Read the Quran fluently with guided reading practice." },
  { id: "tajweed", name: "Tajweed", arabic: "التجويد", desc: "Learn correct pronunciation and the rules of Quran recitation." },
  { id: "hifz", name: "Hifz", arabic: "الحفظ", desc: "Memorize the Holy Quran with a dedicated teacher and steady revision." },
  { id: "kitab", name: "Kitab", arabic: "الكتاب", desc: "Study Islamic books: Fiqh, Aqeedah, Hadith and Arabic." },
] as const;

export type CourseId = (typeof COURSES)[number]["id"];
export const courseName = (id: string) => COURSES.find((c) => c.id === id)?.name ?? (id === "nazra_tajweed" ? "Nazra & Tajweed (previous course)" : id);

export const registrationSchema = z.object({
  course: z.enum(["qaida", "nazra", "tajweed", "hifz", "kitab"]),
  full_name: z.string().trim().min(1, "Name is required").max(100),
  gender: z.enum(["male", "female"]),
  age: z.coerce.number().int().min(3, "Age must be 3 or more").max(100),
  phone: z.string().trim().min(5, "Phone is required").max(30),
  email: z.string().trim().email("Invalid email").max(255).optional().or(z.literal("")),
  location: z.string().trim().min(1, "Country / city is required").max(120),
  level: z.enum(["beginner", "some", "advanced"]),
  preferred_time: z.enum(["morning", "afternoon", "evening"]),
  notes: z.string().trim().max(1000).optional().or(z.literal("")),
});
