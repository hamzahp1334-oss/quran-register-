import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { courseName } from "@/lib/courses";

const rowSchema = z.object({
  course: z.string(),
  full_name: z.string(),
  gender: z.string(),
  age: z.number(),
  phone: z.string(),
  email: z.string().nullable(),
  location: z.string(),
  level: z.string(),
  preferred_time: z.string(),
  notes: z.string().nullable(),
});

export const appendRegistrationToSheet = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => rowSchema.parse(data))
  .handler(async ({ data }) => {
    const spreadsheetId = process.env["GOOGLE_SHEETS_SPREADSHEET_ID"];
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const connectionKey = process.env["GOOGLE_SHEETS_API_KEY"];
    if (!spreadsheetId || !lovableKey || !connectionKey) {
      throw new Error("Google Sheets connection is not configured");
    }

    const row = [
      new Date().toISOString(),
      courseName(data.course),
      data.full_name,
      data.gender,
      String(data.age),
      "", // Preserve existing spreadsheet columns; guardian name is no longer collected.
      data.phone,
      data.email ?? "",
      data.location,
      data.level,
      data.preferred_time,
      data.notes ?? "",
      "new",
    ];

    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${spreadsheetId}/values/Registrations!A1:M1:append?valueInputOption=RAW`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": connectionKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ values: [row] }),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(`Google Sheets sync failed [${response.status}]: ${errorBody}`);
      throw new Error(`Google Sheets sync failed [${response.status}]`);
    }
    return { ok: true };
  });
