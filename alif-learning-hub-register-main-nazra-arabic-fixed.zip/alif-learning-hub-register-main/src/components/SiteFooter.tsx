export const MAKER_EMAIL = "atomisterx@gmail.com";
export const MAKER_TELEGRAM = "https://t.me/atomisterx";

export function SiteFooter() {
  return (
    <footer className="border-t border-border px-5 py-8 text-sm text-muted-foreground">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 text-center">
        <p>© {new Date().getFullYear()} Alif Online Learning</p>
        <p className="font-medium text-primary">Made by X-STUDIO</p>
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
          <a href={`mailto:${MAKER_EMAIL}`} className="inline-flex min-h-11 items-center gap-2 rounded-sm hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring">
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0" aria-hidden="true">
              <path className="gmail-blue" d="M2 6v13h4V9z" />
              <path className="gmail-green" d="M18 9v10h4V6z" />
              <path className="gmail-red" d="M6 4l6 4.5L18 4v5l-6 4.5L6 9z" />
              <path className="gmail-dark-red" d="M2 6a2 2 0 0 1 3.2-1.6L6 5v4L2 6z" />
              <path className="gmail-yellow" d="M18 5l.8-.6A2 2 0 0 1 22 6l-4 3z" />
            </svg>
            <span>{MAKER_EMAIL}</span>
          </a>
          <a href={MAKER_TELEGRAM} target="_blank" rel="noopener noreferrer" aria-label="@atomisterx on Telegram — opens in a new tab" className="inline-flex min-h-11 items-center gap-2 rounded-sm hover:text-primary focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring">
            <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0" aria-hidden="true">
              <circle cx="12" cy="12" r="12" className="telegram-brand" />
              <path className="telegram-mark" d="m5.1 11.6 13-5c.6-.2 1 .1.8.8l-2.2 10.4c-.2.7-.6.8-1.1.5l-3.4-2.5-1.6 1.6c-.2.2-.3.3-.6.3l.2-3.5 6.3-5.7c.3-.3-.1-.4-.4-.2l-7.8 4.9-3.3-1c-.7-.2-.7-.5.1-.8z" />
            </svg>
            <span>@atomisterx</span>
          </a>
        </div>
      </div>
    </footer>
  );
}