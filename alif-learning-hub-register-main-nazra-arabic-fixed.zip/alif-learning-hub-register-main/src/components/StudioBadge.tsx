export const STUDIO_BADGE_URL = "https://t.me//atomisterx";

export function isPublicBadgePage(pathname: string) {
  return !/^\/(admin|login|signin|sign-in|auth)(\/|$)/.test(pathname);
}

export function StudioBadge() {
  return (
    <a
      className="studio-badge"
      href={STUDIO_BADGE_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Made by X-STUDIO — opens in a new tab"
    >
      <img
        src="/x-studio-badge.png"
        alt="MADE BY X-STUDIO"
        width={1983}
        height={793}
        draggable={false}
      />
    </a>
  );
}