import { Link } from "@tanstack/react-router";

export function SiteHeader() {
  return (
    <header className="border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-4">
        <Link to="/" className="flex min-w-0 items-center gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary font-arabic text-2xl text-gold">ا</span>
          <span className="font-display text-xl font-semibold text-primary sm:text-2xl">Alif Online Learning</span>
        </Link>
        <Link to="/register" className="shrink-0 rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
          Register
        </Link>
      </div>
    </header>
  );
}
