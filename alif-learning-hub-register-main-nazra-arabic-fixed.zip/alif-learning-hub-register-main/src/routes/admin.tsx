import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/SiteHeader";
import { COURSES, courseName } from "@/lib/courses";
import {
  deleteRegistration,
  getAdminRegistrations,
  updateRegistrationStatus,
  verifyAdminPassword,
} from "@/lib/admin.functions";
import type { Tables } from "@/integrations/supabase/types";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin — Alif Online Learning" },
      { name: "description", content: "Manage student registrations." },
      { property: "og:title", content: "Admin — Alif Online Learning" },
      { property: "og:description", content: "Manage student registrations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const field = "w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring";
const STORAGE_KEY = "alif-admin-password";

function AdminPage() {
  const [password, setPassword] = useState<string | null | undefined>(undefined);

  useEffect(() => {
    const saved = sessionStorage.getItem(STORAGE_KEY);
    if (!saved) {
      setPassword(null);
      return;
    }
    verifyAdminPassword({ data: { password: saved } })
      .then(() => setPassword(saved))
      .catch(() => {
        sessionStorage.removeItem(STORAGE_KEY);
        setPassword(null);
      });
  }, []);

  return (
    <div className="min-h-screen font-sans">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-12">
        {password === undefined ? null : !password ? (
          <Login
            onSuccess={(pw) => {
              sessionStorage.setItem(STORAGE_KEY, pw);
              setPassword(pw);
            }}
          />
        ) : (
          <Dashboard
            password={password}
            onLock={() => {
              sessionStorage.removeItem(STORAGE_KEY);
              setPassword(null);
            }}
          />
        )}
      </main>
    </div>
  );
}

function Login({ onSuccess }: { onSuccess: (password: string) => void }) {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      await verifyAdminPassword({ data: { password } });
      onSuccess(password);
    } catch {
      toast.error("Wrong password.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="mx-auto max-w-sm space-y-4 rounded-2xl border border-border bg-card p-8 shadow-elegant">
      <h1 className="font-display text-3xl font-semibold text-primary">Admin access</h1>
      <p className="text-sm text-muted-foreground">Enter the admin password to view registrations.</p>
      <input
        className={field}
        type="password"
        aria-label="Admin password"
        autoComplete="current-password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        autoFocus
      />
      <button disabled={loading} className="w-full rounded-full bg-primary py-2.5 text-primary-foreground disabled:opacity-60">
        {loading ? "Checking…" : "Unlock"}
      </button>
    </form>
  );
}

type Reg = Tables<"registrations">;

function Dashboard({ password, onLock }: { password: string; onLock: () => void }) {
  const [rows, setRows] = useState<Reg[]>([]);
  const [course, setCourse] = useState("all");
  const [q, setQ] = useState("");

  async function load() {
    try {
      setRows(await getAdminRegistrations({ data: { password } }));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not load registrations");
    }
  }
  useEffect(() => { load(); }, []);

  const filtered = useMemo(
    () => rows.filter((r) => (course === "all" || r.course === course) && (`${r.full_name} ${r.phone}`.toLowerCase().includes(q.toLowerCase()))),
    [rows, course, q],
  );

  async function setStatus(id: string, status: "new" | "contacted" | "enrolled") {
    try {
      await updateRegistrationStatus({ data: { password, id, status } });
      setRows((r) => r.map((x) => (x.id === id ? { ...x, status } : x)));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Update failed");
    }
  }
  async function remove(id: string) {
    if (!confirm("Delete this registration?")) return;
    try {
      await deleteRegistration({ data: { password, id } });
      setRows((r) => r.filter((x) => x.id !== id));
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed");
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-semibold text-primary">Registrations</h1>
          <p className="text-sm text-muted-foreground">{rows.length} total</p>
        </div>
        <button onClick={onLock} className="text-sm underline">Lock</button>
      </div>
      <div className="mt-6 grid gap-3 sm:grid-cols-5">
        {COURSES.map((c) => (
          <div key={c.id} className="rounded-xl border border-border bg-card p-4">
            <p className="text-sm text-muted-foreground">{c.name}</p>
            <p className="font-display text-3xl font-semibold text-primary">{rows.filter((r) => r.course === c.id).length}</p>
          </div>
        ))}
      </div>
      <div className="mt-6 flex flex-wrap gap-3">
        <select className={`${field} max-w-xs`} value={course} onChange={(e) => setCourse(e.target.value)}>
          <option value="all">All courses</option>
          {COURSES.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          {rows.some((r) => r.course === "nazra_tajweed") && <option value="nazra_tajweed">{courseName("nazra_tajweed")}</option>}
        </select>
        <input className={`${field} max-w-xs`} placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="mt-4 overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full text-left text-sm">
          <thead className="bg-secondary text-secondary-foreground">
            <tr>{["Date", "Name", "Course", "Age / Gender", "Phone", "Location", "Level / Time", "Notes", "Status", ""].map((h) => <th key={h} className="px-3 py-2.5 font-medium">{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={10} className="p-8 text-center text-muted-foreground">No registrations yet.</td></tr>}
            {filtered.map((r) => (
              <tr key={r.id} className="border-t border-border align-top">
                <td className="px-3 py-2.5 whitespace-nowrap">{new Date(r.created_at).toLocaleDateString()}</td>
                <td className="px-3 py-2.5">{r.full_name}</td>
                <td className="px-3 py-2.5">{courseName(r.course)}</td>
                <td className="px-3 py-2.5">{r.age} / {r.gender}</td>
                <td className="px-3 py-2.5">{r.phone}{r.email && <div className="text-xs text-muted-foreground">{r.email}</div>}</td>
                <td className="px-3 py-2.5">{r.location}</td>
                <td className="px-3 py-2.5">{r.level} / {r.preferred_time}</td>
                <td className="px-3 py-2.5 max-w-xs">{r.notes}</td>
                <td className="px-3 py-2.5">
                  <select
                    className="rounded border border-input bg-card px-2 py-1"
                    value={r.status}
                    onChange={(e) => setStatus(r.id, e.target.value as "new" | "contacted" | "enrolled")}
                  >
                    <option value="new">New</option><option value="contacted">Contacted</option><option value="enrolled">Enrolled</option>
                  </select>
                </td>
                <td className="px-3 py-2.5"><button onClick={() => remove(r.id)} className="text-destructive">Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
