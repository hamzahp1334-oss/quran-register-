import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { COURSES, registrationSchema } from "@/lib/courses";
import { appendRegistrationToSheet } from "@/lib/sheets.functions";

type Search = { course?: string | undefined };

export const Route = createFileRoute("/register")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    course: typeof s["course"] === "string" ? s["course"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Register — Alif Online Learning" },
      { name: "description", content: "Register for Qaida, Nazra, Tajweed, Hifz or Kitab classes at Alif Online Learning." },
      { property: "og:title", content: "Register — Alif Online Learning" },
      { property: "og:description", content: "Sign up for online Quran classes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegisterPage,
});

const field = "w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring";

function F({ label, children, error }: { label: string; children: ReactNode; error?: string | undefined }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-destructive">{error}</span>}
    </label>
  );
}

function RegisterPage() {
  const { course } = Route.useSearch();
  const initial = COURSES.find((c) => c.id === course)?.id ?? "qaida";
  const [selected, setSelected] = useState(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const parsed = registrationSchema.safeParse({ ...data, course: selected });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[String(i.path[0])] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    setLoading(true);
    const v = parsed.data;
    try {
    const { error } = await supabase.from("registrations").insert({
      ...v,
      email: v.email || null,
      notes: v.notes || null,
    });
    if (error) {
      toast.error("Could not submit. Please try again.");
      return;
    }
    // Fire-and-forget: the registration is already saved, so a slow or failed
    // sheet sync must not block the success screen.
    appendRegistrationToSheet({
      data: {
        course: v.course,
        full_name: v.full_name,
        gender: v.gender,
        age: v.age,
        phone: v.phone,
        email: v.email || null,
        location: v.location,
        level: v.level,
        preferred_time: v.preferred_time,
        notes: v.notes || null,
      },
    }).catch((sheetError) => console.error("Sheet sync failed:", sheetError));
    setDone(true);
    } catch {
      toast.error("Could not submit. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen font-sans">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-5 py-14">
        {done ? (
          <div className="rounded-2xl border border-border bg-card p-12 text-center shadow-elegant">
            <p className="font-arabic text-4xl text-gold">جزاك الله خيرا</p>
            <h1 className="mt-4 font-display text-4xl font-semibold text-primary">Registration received</h1>
            <p className="mt-3 text-muted-foreground">We will contact you soon on the phone number you provided.</p>
            <Link to="/" className="mt-8 inline-block rounded-full bg-primary px-6 py-2.5 text-primary-foreground">Back home</Link>
          </div>
        ) : (
          <>
            <h1 className="font-display text-5xl font-semibold text-primary">Student Registration</h1>
            <p className="mt-2 text-muted-foreground">Choose a course and fill in your details.</p>
            <form onSubmit={onSubmit} className="mt-10 space-y-8">
              <div className="grid gap-3 sm:grid-cols-2">
                {COURSES.map((c) => (
                  <button
                    type="button"
                    key={c.id}
                    onClick={() => setSelected(c.id)}
                    className={`rounded-xl border p-4 text-left transition ${selected === c.id ? "border-primary bg-primary text-primary-foreground shadow-elegant" : "border-border bg-card hover:border-primary"}`}
                  >
                    <span className="font-arabic text-xl text-gold">{c.arabic}</span>
                    <span className="ml-3 font-display text-xl font-semibold">{c.name}</span>
                  </button>
                ))}
              </div>
              <div className="grid gap-5 rounded-2xl border border-border bg-card p-6 sm:grid-cols-2">
                <F label="Full name *" error={errors["full_name"]}><input name="full_name" className={field} maxLength={100} /></F>
                <F label="Gender *" error={errors["gender"]}>
                  <select name="gender" className={field} defaultValue="male"><option value="male">Male</option><option value="female">Female</option></select>
                </F>
                <F label="Age *" error={errors["age"]}><input name="age" type="number" min={3} max={100} className={field} /></F>
                <F label="Phone / WhatsApp *" error={errors["phone"]}><input name="phone" type="tel" className={field} maxLength={30} /></F>
                <F label="Email" error={errors["email"]}><input name="email" type="email" className={field} maxLength={255} /></F>
                <F label="Country / city *" error={errors["location"]}><input name="location" className={field} maxLength={120} /></F>
                <F label="Current level *" error={errors["level"]}>
                  <select name="level" className={field} defaultValue="beginner">
                    <option value="beginner">Beginner</option><option value="some">Some knowledge</option><option value="advanced">Advanced</option>
                  </select>
                </F>
                <F label="Preferred class time *" error={errors["preferred_time"]}>
                  <select name="preferred_time" className={field} defaultValue="evening">
                    <option value="morning">Morning</option><option value="afternoon">Afternoon</option><option value="evening">Evening</option>
                  </select>
                </F>
                <div className="sm:col-span-2">
                  <F label="Notes" error={errors["notes"]}><textarea name="notes" rows={3} className={field} maxLength={1000} /></F>
                </div>
              </div>
              <button disabled={loading} className="w-full rounded-full bg-primary py-3.5 font-medium text-primary-foreground shadow-elegant hover:bg-primary/90 disabled:opacity-60">
                {loading ? "Submitting..." : "Submit registration"}
              </button>
            </form>
          </>
        )}
      </main>
    </div>
  );
}
