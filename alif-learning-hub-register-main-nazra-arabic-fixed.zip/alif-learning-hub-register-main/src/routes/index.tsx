import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { COURSES } from "@/lib/courses";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alif Online Learning — Quran Classes Registration" },
      { name: "description", content: "Join Alif Online Learning: Qaida, Nazra, Tajweed, Hifz and Kitab classes online. Register today." },
      { property: "og:title", content: "Alif Online Learning" },
      { property: "og:description", content: "Online Qaida, Nazra, Tajweed, Hifz and Kitab classes. Register today." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen font-sans">
      <SiteHeader />
      <section className="relative overflow-hidden bg-hero text-primary-foreground">
        <div className="pattern absolute inset-0 opacity-40" />
        <div className="relative mx-auto max-w-6xl px-5 py-24 text-center">
          <p className="font-arabic text-3xl text-gold">بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</p>
          <h1 className="mt-6 font-display text-5xl font-semibold md:text-7xl">Learn the Quran, from Alif</h1>
          <p className="mx-auto mt-5 max-w-xl text-lg opacity-85">
            Live online classes with qualified teachers for children and adults. Choose your course and register in a minute.
          </p>
          <Link to="/register" className="mt-9 inline-block rounded-full bg-gold px-8 py-3 font-medium text-accent-foreground shadow-elegant hover:opacity-90">
            Register now
          </Link>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 py-20">
        <h2 className="text-center font-display text-4xl font-semibold text-primary">Our Courses</h2>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {COURSES.map((c) => (
            <Link
              key={c.id}
              to="/register"
              search={{ course: c.id }}
              className="group rounded-2xl border border-border bg-card p-7 transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <p className="font-arabic text-3xl text-gold">{c.arabic}</p>
              <h3 className="mt-3 font-display text-2xl font-semibold text-primary">{c.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{c.desc}</p>
              <p className="mt-5 text-sm font-medium text-primary group-hover:underline">Register →</p>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
