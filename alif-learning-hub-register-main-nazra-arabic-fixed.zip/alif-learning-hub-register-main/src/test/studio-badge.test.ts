import { describe, expect, it } from "vitest";
import { isPublicBadgePage, STUDIO_BADGE_URL } from "@/components/StudioBadge";

describe("X-STUDIO attribution rules", () => {
  it("uses the exact supplied destination", () => {
    expect(STUDIO_BADGE_URL).toBe("https://t.me//atomisterx");
  });

  it("appears on public pages", () => {
    expect(isPublicBadgePage("/")).toBe(true);
    expect(isPublicBadgePage("/register")).toBe(true);
  });

  it("does not appear on administration or login pages", () => {
    expect(isPublicBadgePage("/admin")).toBe(false);
    expect(isPublicBadgePage("/admin/login")).toBe(false);
    expect(isPublicBadgePage("/login")).toBe(false);
    expect(isPublicBadgePage("/auth/login")).toBe(false);
  });
});