import { describe, expect, it } from "vitest";
import { registrationSchema } from "@/lib/courses";
import { MAKER_EMAIL, MAKER_TELEGRAM } from "@/components/SiteFooter";

describe("Registration and maker contacts", () => {
  it("does not collect guardian name", () => {
    const parsed = registrationSchema.parse({ course: "nazra", full_name: "Student", gender: "male", age: 12, phone: "0700000000", location: "Nairobi", level: "beginner", preferred_time: "evening", guardian_name: "Removed field" });
    expect(parsed).not.toHaveProperty("guardian_name");
  });
  it("uses the supplied maker email", () => {
    expect(MAKER_EMAIL).toBe("atomisterx@gmail.com");
  });
  it("uses the supplied maker Telegram username", () => {
    expect(MAKER_TELEGRAM).toBe("https://t.me/atomisterx");
  });
});