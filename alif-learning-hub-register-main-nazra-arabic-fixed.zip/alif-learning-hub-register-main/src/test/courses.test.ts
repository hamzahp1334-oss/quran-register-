import { describe, expect, it } from "vitest";
import { COURSES, courseName, registrationSchema } from "@/lib/courses";

describe("Independent Nazra and Tajweed courses", () => {
  it("offers Nazra as its own accepted course", () => {
    expect(COURSES.find((c) => c.id === "nazra")?.name).toBe("Nazra");
    expect(registrationSchema.shape.course.parse("nazra")).toBe("nazra");
    expect(courseName("nazra")).toBe("Nazra");
  });
  it("offers Tajweed as its own accepted course", () => {
    expect(COURSES.find((c) => c.id === "tajweed")?.name).toBe("Tajweed");
    expect(registrationSchema.shape.course.parse("tajweed")).toBe("tajweed");
    expect(courseName("tajweed")).toBe("Tajweed");
  });
  it("does not offer or accept the combined choice for new registrations", () => {
    expect(COURSES.map((c) => String(c.id))).not.toContain("nazra_tajweed");
    expect(registrationSchema.shape.course.safeParse("nazra_tajweed").success).toBe(false);
  });
});