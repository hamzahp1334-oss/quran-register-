<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Admin area uses a shared password (env `ADMIN_PASSWORD`), not accounts: `src/lib/admin.functions.ts` verifies the password on every call and reads/writes via `supabaseAdmin` — why: the user asked for password-only access, so the password must never ship to the browser.
- Render website attribution once in the root using the reusable StudioBadge and a shared public-page guard; retain the original upload in public and frame its transparent margins with CSS — why: consistent public-only placement without changing the artwork or individual page layouts.
- Use the shared course catalog and courseName helper for registration, admin, and Google Sheets labels; retain legacy course identifiers for historical rows only — why: consistent separate course choices without reclassifying existing registrations.
- Render the shared maker footer at the root on public pages only; keep retired guardian storage and the blank spreadsheet column for compatibility — why: consistent contacts and safe preservation of historical registrations.
